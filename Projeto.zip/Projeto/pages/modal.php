<div class='cor'>
    <div class='cor-header'>
        <h2 class='texto'>Monitor(a): Gabriela Nunes</h2>
        <p class='texto'>Curso: ADM</p>
    </div>
    <div class='cor-body'>
        <p>Disciplina: História</p>
        <p>Professor(es): Fabiana Gomes, Paulo Santana</p>
        <p>Local: Sala 302</p>
        <p>horário: 14h - 14:50h</p>
        <p>Publico: 1° Ano</p>
    </div>
    <div class='cor-botao'>
        <label>
            <input class='custom-checkbox' type="checkbox" name="check">
            <p>Eu vou</p>
        </label>
    </div>
    <div class='cor-sair' onclick="fecharModal()">
        <p class='sair'>x</p>
    </div>
</div>
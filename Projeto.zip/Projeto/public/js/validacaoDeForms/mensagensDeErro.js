export const mensagensErroLogin = {
    'usuario_senha_incorreta': 'Sua senha está incorreta tente novamente mais tarde!',
    'usuario_nao_enontrado': 'Usuário não encontrado no sistema.'
};
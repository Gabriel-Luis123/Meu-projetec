document.getElementById('botaoConfirmarEdicao').addEventListener('click', () => {
    window.location.href = 'minhas_monitorias.php';
});